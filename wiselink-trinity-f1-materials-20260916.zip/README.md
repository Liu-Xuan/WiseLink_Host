# WiseLink Trinity 1.0 · 2026-09-16

从 `start.html` 阅读导览，或打开 `situation.html` 看宏观双环。全部产品页面离线内嵌资源，不依赖CDN。

外环为工程业务生命周期，内环为知识循环，中间为智能体。态势、时间轴、图谱共享观察身份；资料库、知识、Wiki与独立文档精读作为阅读落点。`DESIGN.md`/`design.html`是完整规范；`visual-lab.html`是离线截图叠图对照台；`prompts`提供妙搭任务书。

## 使用和构建

直接打开HTML即可。保留目录可打开PDF、工具和设计文件。文件协议被浏览器限制时，可在本目录运行 `python -m http.server 8765`。生产使用当前React/Host，不将离线prototype嵌为iframe，不把fixture部署为业务真源。

`tools/build.py`重新生成18个产品入口（会覆盖首屏预渲染）；`tools/capture.py`运行页面检查并生成参考截图/预渲染；`tools/build_docs.py`生成设计/导览；`tests/browser_test.py`和`tests/artifact_test.py`记录实际检查。示例Playwright TS文件是接线范例，没有计入本轮执行结果。

## 数据与技术边界

全部业务内容为明确构造：16事项、21文档版本、15时间记录、6知识工作。不是当前Host、真实飞机或厂家指令。7份构造PDF按实际排版渲染，只证明本地示例定位。未连接OpenClaw、Aily、正式业务系统；没有修改仓库或生产数据。

Cytoscape.js沿用3.33.1，许可证及本地回收构建说明在vendor。双环为普通HTML按钮和固定SVG示意线，非自建图谱引擎。样式与动态已提供三档及reduced-motion。没有字体文件、密钥或外部遥测。

本轮没有重新核实线上发布状态。项目文档中的旧MVP或旧六信息外环保留历史语义来源，其中与当前用户双环设计冲突处由本版明确替代。
