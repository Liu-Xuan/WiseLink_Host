/* Paste in the application frame's console. Read-only: no network, storage or business mutation.
 * It intentionally does not collect user text, draft values, URL query, tokens or source IDs.
 * Existing React implementation: add data-geometry to the comparable layout containers.
 */
(() => {
  const round = n => Math.round(n * 100) / 100;
  const selectors = [
    '[data-geometry="sidebar"]', '[data-geometry="topbar"]', '[data-geometry="main"]',
    '[data-geometry="metrics"]', '.ring-card', '.ring-stage', '.agent-core',
    '.stage-node', '.knowledge-node', '[data-geometry="inspector"]',
    '.scope-bar', '.view-nav', '.library-layout', '.reader-layout', '.reader-columns',
    '.time-map', '.timeline-layout', '[data-geometry="graph-main"]', '#cy'
  ];
  const allowed = ['display','position','width','height','padding','gap','fontFamily','fontSize','fontWeight',
    'lineHeight','color','backgroundColor','borderColor','borderRadius','boxShadow','backdropFilter','opacity'];
  const nodes = [];
  for (const selector of selectors) {
    [...document.querySelectorAll(selector)].forEach((el,index) => {
      const rect = el.getBoundingClientRect(), cs = getComputedStyle(el);
      nodes.push({selector,index,visible:!!(rect.width&&rect.height),
        box:{x:round(rect.x),y:round(rect.y),width:round(rect.width),height:round(rect.height)},
        style:Object.fromEntries(allowed.map(k=>[k,cs[k]]))});
    });
  }
  const report = {version:'Trinity 1.0 visual probe',capturedAt:new Date().toISOString(),
    environment:{innerWidth,innerHeight,devicePixelRatio,scrollWidth:document.documentElement.scrollWidth,
      visualViewport:window.visualViewport?{width:round(visualViewport.width),height:round(visualViewport.height),scale:visualViewport.scale}:null,
      userAgent:navigator.userAgent,fontsStatus:document.fonts?.status,
      reducedMotion:matchMedia('(prefers-reduced-motion: reduce)').matches,
      theme:document.documentElement.dataset.theme,effects:document.documentElement.dataset.effects,
      media:{under1200:matchMedia('(max-width:1200px)').matches,under640:matchMedia('(max-width:640px)').matches}},nodes};
  console.log(JSON.stringify(report,null,2));
  return report;
})();
